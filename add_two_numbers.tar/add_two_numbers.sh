#!/bin/bash
declare -i num1
declare -i num2
declare -i total
echo "enter a number"
read num1
echo "enter another number"
read num2
total=num1+num2
echo "the sum is:" $total
exit 0
